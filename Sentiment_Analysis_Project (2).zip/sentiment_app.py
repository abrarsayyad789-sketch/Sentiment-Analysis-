
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

# Simple demo dataset
data = pd.DataFrame({
    "text": [
        "I love this product",
        "This is terrible",
        "Amazing experience",
        "Worst service ever",
        "I feel great today",
        "I am very disappointed"
    ],
    "label": [1,0,1,0,1,0]
})

X_train, X_test, y_train, y_test = train_test_split(
    data["text"], data["label"], test_size=0.2, random_state=42
)

model = Pipeline([
    ("tfidf", TfidfVectorizer(stop_words="english")),
    ("clf", LogisticRegression())
])

model.fit(X_train, y_train)
acc = model.score(X_test, y_test)
print(f"Test Accuracy: {acc:.2f}")

# Example prediction
sample = ["I really liked this movie"]
print("Sample prediction:", model.predict(sample)[0])
