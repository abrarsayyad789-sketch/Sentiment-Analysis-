
# Sentiment Analysis Project

A simple sentiment analysis pipeline that classifies text as positive or negative using:
- TF–IDF feature extraction
- Logistic Regression classifier
- scikit-learn Pipeline

How to run:
1. Install dependencies:
   pip install -r requirements.txt

2. Run:
   python sentiment_app.py

You can replace the sample dataset with IMDB, Twitter, or any review dataset.
